# Hello world bot

A simple hello world discord bot written in python.