select * from target t 
select * from "change" c 


INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:34.989773', '2024-07-04 16:34:34.989773', 'vietcongonbush', 'VietCong');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:34.996318', '2024-07-04 16:34:34.996318', 'vietcong696', 'VietCong');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:35.002144', '2024-07-04 16:34:35.002144', '76561199522144309', 'Styles');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:35.007103', '2024-07-04 16:34:35.007103', '76561198873873171', 'Styles');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:35.012365', '2024-07-04 16:34:35.012365', '76561198985659397', 'Styles');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:35.017397', '2024-07-04 16:34:35.017397', '76561198006579324', 'Possibly Styles');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-04 16:34:35.022285', '2024-07-04 16:34:35.022285', 'MarkovinaEST', 'Al Saal Yah Ghans');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-05 21:51:12.358256', '2024-07-05 21:51:12.358256', '76561198072917042', 'Magnus (Wallhacks)');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES('2024-07-06 22:48:31.186713', '2024-07-06 22:48:31.186713', 'loveudonz', 'Udon (VC)');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES( '2024-07-06 23:26:58.981593', '2024-07-06 23:26:58.981593', '76561198295518186', 'OG');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES( '2024-07-06 23:36:34.459869', '2024-07-06 23:36:34.459869', '76561199195914218', 'Mad Scientist(VC)');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES( '2024-07-06 23:41:24.694384', '2024-07-06 23:41:24.694384', 'gemtons', 'aliens are real');
INSERT INTO target (created_at, updated_at, steam_id, name) VALUES( '2024-07-06 23:53:06.351141', '2024-07-06 23:53:06.351141', '76561198062150199', 'Krowdexx (VC sympathiser)');

INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:53.075650', '2024-07-04 16:34:53.075650', 'vietcongonbush', 'VietCong with Macro Banned ?');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:53.999498', '2024-07-04 16:34:53.999498', 'vietcong696', 'test-Vietcong696');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:54.709533', '2024-07-04 16:34:54.709533', '76561199522144309', 'Blame Game');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:55.402796', '2024-07-04 16:34:55.402796', '76561198873873171', 'Rev');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:56.100453', '2024-07-04 16:34:56.100453', '76561198985659397', 'Sprite');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:56.815193', '2024-07-04 16:34:56.815193', '76561198006579324', 'test-braveheart2408');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 16:34:57.709751', '2024-07-04 16:34:57.709751', 'MarkovinaEST', 'test-Al Saal Yah Ghans');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 19:24:58.002221', '2024-07-04 19:24:58.002221', '76561199522144309', 'Mia');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES('2024-07-04 22:29:44.344335', '2024-07-04 22:29:44.344335', '76561199522144309', 'kING kAI');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-04 23:12:31.589692', '2024-07-04 23:12:31.589692', '76561199522144309', 'test-Knight');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 12:34:15.291943', '2024-07-05 12:34:15.291943', '76561197971121744', 'Steb');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 12:37:58.730507', '2024-07-05 12:37:58.730507', '76561197971121744', 'Steb');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 12:44:41.605623', '2024-07-05 12:44:41.605623', '76561197971121744', 'Steb');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 12:46:24.307954', '2024-07-05 12:46:24.307954', '76561197971121744', 'Steb');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 12:51:27.965941', '2024-07-05 12:51:27.965941', '76561197971121744', 'Steb1');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 12:51:57.621349', '2024-07-05 12:51:57.621349', '76561197971121744', 'Steb');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 13:20:04.777535', '2024-07-05 13:20:04.777535', '76561198814765900', 'test-Ctrlrz');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:03:52.616905', '2024-07-05 15:03:52.616905', 'vietcong696', 'test-Vietcong696');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:03:52.991367', '2024-07-05 15:03:52.991367', '76561199522144309', 'test-Knight');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:03:54.202323', '2024-07-05 15:03:54.202323', '76561198006579324', 'test-braveheart2408');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:03:54.673930', '2024-07-05 15:03:54.673930', 'MarkovinaEST', 'test-Al Saal Yah Ghans');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:40:39.687927', '2024-07-05 15:40:39.687927', 'vietcong696', 'test-Vietcong696');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:40:40.071698', '2024-07-05 15:40:40.071698', '76561199522144309', 'test-Knight');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:40:41.237583', '2024-07-05 15:40:41.237583', '76561198006579324', 'test-braveheart2408');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:40:41.674558', '2024-07-05 15:40:41.674558', 'MarkovinaEST', 'test-Al Saal Yah Ghans');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:43:22.673999', '2024-07-05 15:43:22.673999', 'vietcong696', 'test-Vietcong696');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:43:23.103204', '2024-07-05 15:43:23.103204', '76561199522144309', 'test-Knight');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:43:24.353008', '2024-07-05 15:43:24.353008', '76561198006579324', 'test-braveheart2408');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:43:24.818230', '2024-07-05 15:43:24.818230', 'MarkovinaEST', 'test-Al Saal Yah Ghans');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:51:27.557637', '2024-07-05 15:51:27.557637', 'vietcong696', 'Vietcong696');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:51:27.926346', '2024-07-05 15:51:27.926346', '76561199522144309', 'Knight');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:51:28.957560', '2024-07-05 15:51:28.957560', '76561198006579324', 'braveheart2408');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 15:51:29.367488', '2024-07-05 15:51:29.367488', 'MarkovinaEST', 'Al Saal Yah Ghans');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 19:25:18.560712', '2024-07-05 19:25:18.560712', '76561199522144309', 'Boxy');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 21:49:48.589729', '2024-07-05 21:49:48.589729', '76561199522144309', 'Bond JAMES Bond');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 21:51:12.363712', '2024-07-05 21:51:12.363712', '76561198072917042', 'magnus');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 21:51:18.853878', '2024-07-05 21:51:18.853878', '76561198873873171', 'Top Hat');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-05 22:22:48.775980', '2024-07-05 22:22:48.775980', '76561199522144309', 'JinxX');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 18:30:45.663912', '2024-07-06 18:30:45.663912', '76561199522144309', 'Dizzy');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 20:32:15.563308', '2024-07-06 20:32:15.563308', '76561199522144309', 'Chris');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 22:48:31.193161', '2024-07-06 22:48:31.193161', 'loveudonz', 'Udonchan❸');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 23:26:58.986553', '2024-07-06 23:26:58.986553', '76561198295518186', 'OGz');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 23:36:34.465325', '2024-07-06 23:36:34.465325', '76561199195914218', 'mad scientist');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 23:41:24.699343', '2024-07-06 23:41:24.699343', 'gemtons', '[CE5]Aliens Are Real');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-06 23:53:06.357093', '2024-07-06 23:53:06.357093', '76561198062150199', 'Krowdexx');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-07 20:23:59.938319', '2024-07-07 20:23:59.938319', '76561199522144309', 'Sneaky');
INSERT INTO "change" (created_at, updated_at, steam_id, alias) VALUES( '2024-07-07 22:37:29.616884', '2024-07-07 22:37:29.616884', '76561199522144309', 'Teddy');
























