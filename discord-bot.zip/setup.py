#!/usr/bin/env python

from distutils.core import setup

setup(
    name="discord_hello_world_bot",
    version="1.0",
    description="foo",
    license="MIT",
    author="Steb Jansen",
    author_email="thats.luffley@gmail.com",
    install_requires=["discord","peewee","requests","BeautifulSoup"],
)
